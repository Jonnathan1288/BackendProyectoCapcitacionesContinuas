package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.Programas;

public interface ProgramaService extends GenericService<Programas, Integer>{
}

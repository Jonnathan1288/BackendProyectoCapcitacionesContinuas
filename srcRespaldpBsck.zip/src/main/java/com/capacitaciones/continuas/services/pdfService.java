package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.Area;
import com.capacitaciones.continuas.Modelos.Primary.PruebaPdf;

public interface pdfService extends  GenericService<PruebaPdf, Integer>{
}

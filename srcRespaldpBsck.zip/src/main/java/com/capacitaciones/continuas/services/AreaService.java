package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.Area;

public interface AreaService extends  GenericService<Area, Integer>{
}

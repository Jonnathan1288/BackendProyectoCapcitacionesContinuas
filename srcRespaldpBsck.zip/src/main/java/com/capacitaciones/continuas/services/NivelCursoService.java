package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.NivelCurso;

public interface NivelCursoService extends  GenericService<NivelCurso, Integer>{
}

package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.PeriodoPrograma;

public interface PeriodoProgramaService extends  GenericService<PeriodoPrograma, Integer>{
}

package com.capacitaciones.continuas.repositorys.Primarys;

import com.capacitaciones.continuas.Modelos.Primary.DocumentoSenecyt;
import com.capacitaciones.continuas.Modelos.Primary.PruebaPdf;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentoSenecytRepository extends JpaRepository<DocumentoSenecyt, Integer> {
}

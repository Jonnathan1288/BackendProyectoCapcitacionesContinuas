package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.HorarioCurso;

public interface HorarioCursoService extends GenericService<HorarioCurso, Integer>{
}

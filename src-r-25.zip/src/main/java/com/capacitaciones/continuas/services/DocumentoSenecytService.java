package com.capacitaciones.continuas.services;

import com.capacitaciones.continuas.Modelos.Primary.DocumentoSenecyt;
import com.capacitaciones.continuas.Modelos.Primary.PruebaPdf;

public interface DocumentoSenecytService extends  GenericService<DocumentoSenecyt, Integer>{
}

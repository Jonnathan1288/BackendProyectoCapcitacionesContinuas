package com.capacitaciones.continuas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapacitacionesContinuasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapacitacionesContinuasApplication.class, args);
	}



}
